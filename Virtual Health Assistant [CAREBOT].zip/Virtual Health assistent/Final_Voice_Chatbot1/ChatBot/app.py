from flask import Flask, request, jsonify, render_template
from transformers import RagTokenizer, RagRetriever, RagTokenForGeneration
import torch
import google.generativeai as genai
import voice

def rag_model(key, question):
    try:
        # Load tokenizer, retriever, and model
        tokenizer = RagTokenizer.from_pretrained("facebook/rag-token-base")
        retriever = RagRetriever.from_pretrained("facebook/rag-token-base", index_name="exact", use_dummy_dataset=True)
        model = RagTokenForGeneration.from_pretrained("facebook/rag-token-base", retriever=retriever)

        # Tokenize the input question
        inputs = tokenizer(question, return_tensors="pt")

        # Generate answer
        with torch.no_grad():
            generated_ids = model.generate(input_ids=inputs["input_ids"])
        
        # Decode the generated answer
        answer = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return answer
    
    except Exception as e:
        return f"Error: {str(e)}"

app = Flask(__name__)

# 1. Securely get API key from environment variable
api_key = "AIzaSyBEWbGKJ5tOFjTdfbZ8wRMz1G5DyLV5U9E"

# 2. Configure genai with the retrieved key
genai.configure(api_key=api_key)

# 3. Set generation config (consistent with your other code)
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# 4. Initialize the model with the config
model = genai.GenerativeModel(
    model_name="gemini-2.0-flash-exp",  # Or "gemini-pro" if needed
    generation_config=generation_config,
)

@app.route('/')
def home():
    return render_template('test.html')

@app.route('/chat_page')
def chat_page():
    return render_template('index.html')

@app.route('/get-response', methods=['POST'])
def get_response():
    user_message = request.json.get('message', '')
    if not user_message:
        return jsonify({'error': 'No message provided'}), 400

    # 5. Use start_chat and send_message for chat history (if needed)
    chat_session = model.start_chat(history=[])  # Initialize chat history
    response = chat_session.send_message('''give me the response as a plain text in a precise manner don't make any text styling and maintian the response in a medical context and don't repeat the same response content and make general converstaions if needed and if the questin is like
                                         'I am not feeling well' or I have fever(any other symptoms) ask for some general information like 'How many days you have' , 'your age', 'have any medicines' like general info or if the query is like
                                          'refer or give some doctor or specialist near me' then give only the name of those doctors  their contact their address,  reviews no any other data is needed give me only that if doctor name, address, phone number in the specified region is asked so the user query is: ''' + user_message) # Send message to current chat session
    result = voice.english_to_tamil_voice(response.text, 'en') 
    return jsonify({'bot_message': response.text})

if __name__ == '__main__':
    app.run(debug=True)